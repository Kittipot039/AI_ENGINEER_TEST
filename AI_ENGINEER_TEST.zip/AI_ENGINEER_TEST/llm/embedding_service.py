from langchain_huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS

def create_retriever(texts):
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2",
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': False}
    )
    vectorstore = FAISS.from_documents(texts, embeddings)
    return vectorstore.as_retriever()