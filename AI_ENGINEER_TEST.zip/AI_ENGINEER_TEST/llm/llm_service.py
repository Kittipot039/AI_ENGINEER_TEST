import ollama
from llm.embedding_service import create_retriever
from llm.pdf_loader import load_pdfs
from config import PDF_PATHS

# โหลดข้อมูล + retriever
texts = load_pdfs(PDF_PATHS)
retriever = create_retriever(texts)

def generate_response(query_text):
    docs = retriever.invoke(query_text)
    context = "\n".join([doc.page_content for doc in docs])

    prompt = f"""You are an internal AI assistant that helps the product and engineering team extract 
    insights from internal documents and team reports. Use information from context to answer.
    If you can't find information that match the user's question, just say you don't find information.:\n{context}\nQuestion: {query_text}"""

    response = ollama.chat(model="llama3.2", messages=[
        {"role": "system", "content": """You are an assistant that extracts structured insights from documents.
        You must always reply with a JSON object like this:
        {
          "Feedback #n": "...",
          "Bug #n": {
            "Title": "..."
          }
        }
        """},
        {"role": "user", "content": prompt}
    ])

    return response["message"]["content"]
