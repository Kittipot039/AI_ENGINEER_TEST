import fitz
from langchain.docstore.document import Document

def load_pdfs(pdf_paths):
    texts = []
    for file_path in pdf_paths:
        doc = fitz.open(file_path)
        for i, page in enumerate(doc):
            content = page.get_text()
            if content.strip():
                texts.append(Document(
                    page_content=content,
                    metadata={"source": file_path, "page": i + 1}
                ))
    return texts