from fastapi import FastAPI
from app.api import router # import router ที่เราเขียนใน api.py

app = FastAPI()
app.include_router(router) # เชื่อม router ที่เรา import เข้ามา