import os
from dotenv import load_dotenv

load_dotenv()

HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")

# config.py
base_dir = os.path.dirname(__file__)  # ได้ path ของไฟล์ config.py

# ใช้ os.path.join เพื่อรวม path ให้ถูกต้อง
PDF_PATHS = [
    os.path.join(base_dir, "data", "ai_test_bug_report.pdf"),
    os.path.join(base_dir, "data", "ai_test_user_feedback.pdf")
]