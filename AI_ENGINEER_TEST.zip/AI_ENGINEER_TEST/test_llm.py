from llm.llm_service import generate_response

question = "What are the issues reported on email notification?"

answer = generate_response(question)

print("🧠 Answer:", answer)