from fastapi import APIRouter
from pydantic import BaseModel
from llm.llm_service import generate_response

# สร้าง router สำหรับ endpoint
router = APIRouter()

class QuestionRequest(BaseModel):
    question: str

# ตัวอย่าง route /ask
@router.post("/ask")
async def ask_question(request: QuestionRequest):
    # ส่งคำถามจาก request ไปให้ฟังก์ชัน generate_response
    answer = generate_response(request.question)  # request คือออบเจ็กต์ที่มีคุณสมบัติ question ที่เราอยากจะส่งให้ฟังก์ชัน generate_response
    
    return answer